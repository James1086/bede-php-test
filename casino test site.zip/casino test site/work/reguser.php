<?php
session_start();

$servername = "localhost";
$username = "partybal_user";
$password = "ac1ccxyz";
$dbname = "partybal_work";
$tbl_name="user";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// username and password sent from form 
$newusername=$_POST['newusername'];
$newpassword=$_POST['newpassword'];
$newemail=$_POST['newemail'];

// To protect MySQL injection (more detail about MySQL injection)
$newusername = stripslashes($newusername);
$newpassword = stripslashes($newpassword);
$newemail = stripslashes($newemail);
$newusername = $conn->real_escape_string($newusername);
$newpassword = $conn->real_escape_string($newpassword);
$newemail = $conn->real_escape_string($newemail);

// Test MD5 password
$newpassword = md5($newpassword);

$activation_key = md5($newemail);

$sql = "INSERT INTO user ( name, email, password, verification ) VALUES ( '$newusername', '$newemail', '$newpassword', '$activation_key' )";
$insert = $conn->query($sql);

if ($insert === TRUE) {
	$to = $newemail;
	$subject = "No Fuss Design - Email Verification";
	
	// START HTML EMAIL CONTENT
	$txt = '
	
<table class="body-wrap" bgcolor="#eeeeee" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; width: 100%; margin: 0; padding: 20px;"><tr style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
<td style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
    <td class="container" bgcolor="#FFFFFF" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; clear: both !important; display: block !important; max-width: 600px !important; Margin: 0 auto; padding: 20px;">

      <!-- content -->
      <div class="content" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; display: block; max-width: 600px; margin: 0 auto; padding: 0;">
      <table style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; width: 100%; margin: 0; padding: 0;"><tr style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
<td style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
            <h1 style="font-family: sans-serif; font-size: 36px; line-height: 1.2em; color: #59557e; font-weight: 200; margin: 40px 0 10px; padding: 0;">Hello,</h1>
            <p style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6em; color: #59557e; font-weight: normal; margin: 0 0 10px; padding: 0;">You\'ve signed up to No Fuss Design but we need to verify this email address.</p>
            <!-- button -->
            <table class="btn-primary" cellpadding="0" cellspacing="0" border="0" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; width: auto !important; Margin: 0 0 10px; padding: 0;"><tr style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
<td style="font-family: sans-serif; font-size: 14px; line-height: 1.6em; border-radius: 25px; text-align: center; vertical-align: top; background: #348eda; margin: 0; padding: 0;" align="center" bgcolor="#348eda" valign="top">
                  <a href="http://www.nofussdesign.co.uk/work/index.php?key='.$activation_key.'" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 2; display: inline-block; cursor: pointer; font-weight: bold; text-decoration: none; margin: 0; border-color: #348eda; border-style: solid; border-width: 10px 20px; border: 0px; padding: 10px; border-radius: 5px; background: #ed4b55; color: #fff;">Verify now &raquo;</a>
                </td>
              </tr></table>
			<!-- /button -->
          </td>
        </tr></table>
</div>
      <!-- /content -->
      
    </td>
    <td style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
  </tr></table>
<!-- /body --><!-- footer --><table class="footer-wrap" bgcolor="#eeeeee" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; clear: both !important; width: 100%; margin: 0; padding: 0;"><tr style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
<td style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
    <td class="container" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; clear: both !important; display: block !important; max-width: 600px !important; margin: 0 auto; padding: 0;">
      
      <!-- content -->
      <div class="content" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; display: block; max-width: 600px; margin: 0 auto; padding: 0;">
        <table style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; width: 100%; margin: 0; padding: 0;"><tr style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
<td align="center" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
              <p style="font-family: Arial, sans-serif; font-size: 12px; line-height: 1.6em; color: #666666; font-weight: normal; margin: 0 0 10px; padding: 0;">&copy; 2015 <a href="http://www.nofussdesign.co.uk/" style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; color: #999999; margin: 0; padding: 0;">No Fuss Design</a>.
              </p>
            </td>
          </tr></table>
</div>
      <!-- /content -->
      
    </td>
    <td style="font-family: Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
  </tr></table>	
	';
	// END EMAIL HTML CONTENT
	
	$headers = "From: info@nofussdesign.co.uk\r\n";
	$headers .= "To: info@nofussdesign.co.uk\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

	mail($to,$subject,$txt,$headers);
} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
}


/*
$result = $conn->query("SELECT * FROM $tbl_name WHERE name='$newusername' and password='$newpassword'");

$count = $result->num_rows;

if($count == 1) {
	// Register $newusername, $newpassword and redirect to file "login_success.php"

	$_SESSION['newusername'] = $newusername;
	$_SESSION['newpassword'] = $newpassword;
	header('location:login_success.php');
} else {
	echo "Wrong Username or Password";
}
*/
?>

<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>
</head>

<body>

<div class="wrapper login-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="verification-header">
					<strong>Verification Email Sent</strong>
					<p>Thank you for registering. A verification email has been sent to <b><?php echo $newemail ?></b>.</p>
					<p>Click the verify email link on the email to verify your account and you will be able to use your account to access nofussdesign.co.uk in the future.</p>
					<p><a href="http://www.nofussdesign.co.uk/work">Click here to log in now</a></p>
				</div>
			</div>
		</div>
	</div>
</div>

</body>