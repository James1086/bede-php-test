<?php 
session_start();
session_destroy();
if(!session_is_registered(myusername)){
header("location:index.php");
}
?>