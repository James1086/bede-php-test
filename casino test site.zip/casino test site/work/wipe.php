<?php
$servername = "localhost";
$username = "partybal_user";
$password = "ac1ccxyz";
$dbname = "partybal_work";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user ( name, email ) VALUES ( '{$conn->real_escape_string($_POST['name'])}', '{$conn->real_escape_string($_POST['email'])}' )";

// sql to delete a record
$sql = "DELETE FROM user";

if ($conn->query($sql) === TRUE) {
    echo "All data deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>

<a href="index.php">Back</a>