<?php
session_start();

$servername = "localhost";
$username = "partybal_user";
$password = "ac1ccxyz";
$dbname = "partybal_work";
$tbl_name="user";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// username and password sent from form 
$myusername=$_POST['myusername']; 
$mypassword=$_POST['mypassword']; 

// To protect MySQL injection (more detail about MySQL injection)
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = $conn->real_escape_string($myusername);
$mypassword = $conn->real_escape_string($mypassword);

// Test MD5 password
$mypassword = md5($mypassword);

$result = $conn->query("SELECT * FROM $tbl_name WHERE name='$myusername' and password='$mypassword'");

$count = $result->num_rows;

if($count == 1) {
	// Register $myusername, $mypassword and redirect to file "login_success.php"

	$_SESSION['myusername'] = $myusername;
	$_SESSION['mypassword'] = $mypassword;
	header('location:login_success.php');
} else {
	echo "Wrong Username or Password";
}
?>