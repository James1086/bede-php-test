<?php 
include("head.php");
include("header.php");
?>

<?php
$servername = "localhost";
$username = "partybal_user";
$password = "ac1ccxyz";
$dbname = "partybal_work";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sqlout = "SELECT name, email FROM user";
$result = $conn->query($sqlout);

$activation_key = $_GET['key'];
if(isset($activation_key) && !empty($activation_key)){
	$activation_key = $conn->real_escape_string($activation_key);
	$checkActivationKey = "SELECT name, email, verification, status FROM user WHERE verification = '".$activation_key."'";
	$resKey = $conn->query($checkActivationKey);
	$rows_returned = $resKey->num_rows;
	if($rows_returned > 0){
		$rowKey = $resKey->fetch_assoc();
		if($rowKey['status'] == 0){
			$sqlUpdateUser = $conn->query("UPDATE user SET status = '1' WHERE verification = '".$activation_key."'");
			$msg="Thanks <b>".$rowKey['name']."</b>, your account is now activated."; 
		} else {
			$msg="Your account is already active.";
		}
    }
}

$conn->close();
?>
<div class="wrapper login-wrapper">
	<div class="container-fluid">
	<?php
	if(isset($msg) && !empty($msg)){ ?>
		<div class="row">
			<div class="col-sm-12">
				<div class="verification-header">
					<strong>Verification</strong>
					<p><?php echo $msg; ?></p>
				</div>
			</div>
		</div>

	<?php } ?>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-header">
					<strong>Sign In</strong>
					<p>Sign in using your username and password</p>
				</div>
				<form class="container-fluid login-form" name="form1" method="post" action="checklogin.php">
					<div><input name="myusername" type="text" id="myusername" placeholder="Username"></div>
					<div><input name="mypassword" type="password" id="mypassword" placeholder="Password"></div>
					<input type="submit" name="Submit" value="Login &raquo;">
					<div class="rememberme-wrap"><span><a href="#">Forgot password?</a> / <a href="#">Forgot username?</a></span><input class="rememberme" type="checkbox" name="remember" <?php if(isset($_COOKIE['remember_me'])) {
							echo 'checked="checked"';
						}
						else {
							echo '';
						}
						?> >Remember Me</div>
				</form>
			</div>
			<div class="col-sm-6">
				<div class="form-header">
					<strong>Sign Up</strong>
					<p>Create a new account to log in now</p>
				</div>
				<form class="container-fluid" name="form1" method="post" action="reguser.php">
					<div><input name="newusername" type="text" id="newusername" placeholder="Username"></div>
					<div><input name="newpassword" type="password" id="newpassword" placeholder="Password"></div>
					<div><input name="newemail" type="email" id="newemail" placeholder="Email"></div>
					<input type="submit" name="Submit" value="Sign Up &raquo;">	
				</form>
			</div>
		</div>
	</div>
</div>

<?php 
include("footer.php");
include("foot.php");
?>