<?php
session_start();
if (!isset($_SESSION['myusername'])){
	header("location:index.php");
}
?>

<html>
<body>
Login Successful

<pre>
<?php print_r($_SESSION); ?>
</pre>
</body>
</html>

<form action="logout.php" method="post">
	<input type="submit" name="logout" value="Logout">
</form>