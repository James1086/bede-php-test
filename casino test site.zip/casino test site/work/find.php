<?php
$servername = "localhost";
$username = "partybal_user";
$password = "ac1ccxyz";
$dbname = "partybal_work";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$fieldhasname = $_POST["findname"];
$fieldhasemail = $_POST["findemail"];

if (!empty($fieldhasname) || !empty($fieldhasemail)) {
	if (!empty($fieldhasname) && empty($fieldhasemail)) {
		echo "Find the name: ".$fieldhasname."<br>";
		$sqlout = "SELECT name, email FROM user WHERE name='".$fieldhasname."';";
		$result = $conn->query($sqlout);
		
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<b>Name:</b> " . $row["name"]. " <b>Email:</b> " . $row["email"]. "<br>";
			}
		} else {
			echo "</br>0 results";
		}

		$conn->close();
	}
	if (empty($fieldhasname) && !empty($fieldhasemail)) {
		echo "Find the email: ".$fieldhasemail."<br>";
		$sqlout = "SELECT name, email FROM user WHERE name='".$fieldhasemail."';";
		$result = $conn->query($sqlout);
		
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<b>Name:</b> " . $row["name"]. " <b>Email:</b> " . $row["email"]. "<br>";
			}
		} else {
			echo "</br>0 results";
		}

		$conn->close();
	}
	if (!empty($fieldhasname) && !empty($fieldhasemail)) {
		echo "Find the name: ".$fieldhasname." &amp; the email: ".$fieldhasemail."<br>";
		$sqlout = "SELECT name, email FROM user WHERE name='".$fieldhasname."' AND email='".$fieldhasemail."';";
		$result = $conn->query($sqlout);
		
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<b>Name:</b> " . $row["name"]. " <b>Email:</b> " . $row["email"]. "<br>";
			}
		} else {
			echo "</br>0 results";
		}

		$conn->close();
	}
} else {
	echo "You haven't entered a search term!";
}

?>

<a href="index.php">Back</a>