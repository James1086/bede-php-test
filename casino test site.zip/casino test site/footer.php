<footer>
	<p>&copy; <?php echo date('Y'); ?> James Castelow</p>
</footer>