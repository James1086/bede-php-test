<?php

// dont add a trailing / at the end
define('HTTP_SERVER', 'http://localhost');
// add slash / at the end
define('SITE_DIR', '');

define('SITE_URL', 'www.nofussdesign.co.uk');

define('DB_DRIVER', 'mysql');
define('DB_HOST', 'localhost');
define('DB_HOST_USERNAME', 'partybal_casino');
define('DB_HOST_PASSWORD', 'OL8ovzEWo)!t');
define('DB_DATABASE', 'partybal_casino');
define('DB_PAGE_TABLE', 'pages');

define('SITE_NAME', 'Casino');

?>